package edu.cs3443.utsa.fgu066_lab4;


import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * MainActivity class handles the main screen of the application.
 * It contains buttons to navigate to different activities.
 *
 * @author Jose Perdomo Fgu666
 */

public class MainActivity extends AppCompatActivity {

    /**
     * onCreate method initializes the MainActivity.
     *
     * @param savedInstanceState Saved instance state of the activity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button buttonA = findViewById(R.id.ButtonA);
        Button buttonB = findViewById(R.id.ButtonB);
        Button buttonC = findViewById(R.id.ButtonC);

      buttonA.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v) {
              Intent intent = new Intent(MainActivity.this, StarshipActivity.class);
              intent.putExtra("buttonClicked", "A");
              startActivity(intent);
          }

      });
        buttonB.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StarshipActivity.class);
                intent.putExtra("buttonClicked", "B");
                startActivity(intent);
            }

        });
        buttonC.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StarshipActivity.class);
                intent.putExtra("buttonClicked", "C");
                startActivity(intent);
            }

        });



    }
    }
