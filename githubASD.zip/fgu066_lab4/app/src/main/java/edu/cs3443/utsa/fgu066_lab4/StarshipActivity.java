package edu.cs3443.utsa.fgu066_lab4;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;

import edu.cs3443.utsa.fgu066_lab4.model.Starship;
import edu.cs3443.utsa.fgu066_lab4.model.Fleet;

/**
 * StarshipActivity handles the display of starship details.
 * It loads starship data and crew members dynamically.
 * It displays the appropriate starship based on the button clicked in MainActivity.
 *
 * @author Jose Perdomo Fgu666
 */
public class StarshipActivity extends AppCompatActivity {
    Context context;
    /**
     * Displays an image dynamically based on the member name.
     *
     * @param memName    Name of the crew member
     * @param imageViewId ID of the ImageView to set the image
     */
    public void displayImage(String memName,int imageViewId) {
        Field[] drawablesFields = R.drawable.class.getFields();
        int resourceId = 0;
        for (Field field : drawablesFields) {
            try {
                String drawableName = field.getName();
                if (memName.toLowerCase().contains(drawableName.toLowerCase())) {
                    resourceId = getResources().getIdentifier(drawableName, "drawable", getPackageName());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        ImageView dynamicImage = (ImageView) findViewById(imageViewId);
        dynamicImage.setImageResource(resourceId);
    }
    /**
     * onCreate method initializes the StarshipActivity.
     *
     * @param savedInstanceState Saved instance state of the activity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ArrayList<Starship> sList = new ArrayList<Starship>();
        Fleet fleet = new Fleet("My Fleet", sList);
        Starship ships = new Starship();
        context = this;
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_starship);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Intent intent = getIntent();
        ships.setContext(context);
        fleet.setContext(context);
        try {
            fleet.loadStarships("fleet.csv");
            for (Starship ship : sList) {
                ship.setContext(context);
                ship.loadCrewMembers(ship.getRegistry());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        if(intent.hasExtra("buttonClicked")){
        String clicked = intent.getStringExtra("buttonClicked");
            if(clicked.equals("A")){
                String title =sList.get(3).getName()+"\n"+sList.get(3).getRegistry()+ " ";
                TextView ShipName = (TextView) findViewById(R.id.crewName0);
                ShipName.setText(title);
                for(int i=0;i<8;i++){
                    String crew =sList.get(3).getMember(i);
                    int textViewId = getResources().getIdentifier("crewName" + (i+1), "id", getPackageName());
                    TextView CrewNames = (TextView) findViewById(textViewId);
                    CrewNames.setText(crew);
                    int imageViewId=  getResources().getIdentifier("dynamic_image" +i,"id",getPackageName());
                    displayImage(sList.get(3).getMemberName(i),imageViewId);
                }
            }else if(clicked.equals("B")){
                String title =sList.get(8).getName()+"\n"+sList.get(8).getRegistry()+ " ";
                TextView ShipName = (TextView) findViewById(R.id.crewName0);
                ShipName.setText(title);
                for(int i=0;i<8;i++){
                    String crew =sList.get(8).getMember(i);
                    int textViewId = getResources().getIdentifier("crewName" + (i+1), "id", getPackageName());
                    TextView CrewNames = (TextView) findViewById(textViewId);
                    CrewNames.setText(crew);
                    int imageViewId=  getResources().getIdentifier("dynamic_image" +i,"id",getPackageName());
                    displayImage(sList.get(8).getMemberName(i),imageViewId);
                }
            } else if (clicked.equals("C")) {
                String title =sList.get(4).getName()+"\n"+sList.get(4).getRegistry()+ " ";
                TextView ShipName = (TextView) findViewById(R.id.crewName0);
                ShipName.setText(title);
                for(int i=0;i<8;i++){
                    String crew =sList.get(4).getMember(i);
                    int textViewId = getResources().getIdentifier("crewName" +(i+1) , "id", getPackageName());
                    TextView CrewNames = (TextView) findViewById(textViewId);
                    CrewNames.setText(crew);
                    int imageViewId=  getResources().getIdentifier("dynamic_image" +i,"id",getPackageName());
                    displayImage(sList.get(4).getMemberName(i),imageViewId);
                }
            }


        }




    }
}