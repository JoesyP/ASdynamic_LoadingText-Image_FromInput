package edu.cs3443.utsa.fgu066_lab4.model;

import androidx.annotation.NonNull;

/**
 * CrewMembers class represents a crew member of a starship.
 * It stores information such as name, position, rank, species, and assignment.
 * @author Jose Perdomo Fgu666
 */
public class CrewMembers {
    private String name;
    private String position;
    private String rank;
    private String species;
    private String assignment;

    /**
     * Constructor for CrewMembers with assignment.
     * @param name       The name of the crew member
     * @param position   The position of the crew member
     * @param rank       The rank of the crew member
     * @param species    The species of the crew member
     * @param assignment The assignment of the crew member
     */
    public CrewMembers(String name, String position, String rank, String species, String assignment) {
        this.name = name;
        this.position = position;
        this.rank = rank;
        this.species = species;
        this.assignment = assignment;
    }

    /**
     * Constructor for CrewMembers without assignment.
     * @param name     The name of the crew member
     * @param position The position of the crew member
     * @param rank     The rank of the crew member
     * @param species  The species of the crew member
     */
    public CrewMembers(String name, String position, String rank, String species) {
        this.name = name;
        this.position = position;
        this.rank = rank;
        this.species = species;
    }

    /**
     * Getter for the name of the crew member.
     * @return The name of the crew member
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for the position of the crew member.
     * @return The position of the crew member
     */
    public String getPosition() {
        return position;
    }

    /**
     * Getter for the rank of the crew member.
     * @return The rank of the crew member
     */
    public String getRank() {
        return rank;
    }

    /**
     * Getter for the species of the crew member.
     * @return The species of the crew member
     */
    public String getSpecies() {
        return species;
    }

    /**
     * Getter for the assignment of the crew member.
     * @return The assignment of the crew member
     */
    public String getAssignment() {
        return assignment;
    }

    /**
     * Setter for the name of the crew member.
     * @param name The name of the crew member
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Setter for the position of the crew member.
     * @param position The position of the crew member
     */
    public void setPosition(String position) {
        this.position = position;
    }

    /**
     * Setter for the rank of the crew member.
     * @param rank The rank of the crew member
     */
    public void setRank(String rank) {
        this.rank = rank;
    }

    /**
     * Setter for the assignment of the crew member.
     * @param assignment The assignment of the crew member
     */
    public void setAssignment(String assignment) {
        this.assignment = assignment;
    }

    /**
     * Setter for the species of the crew member.
     * @param species The species of the crew member
     */
    public void setSpecies(String species) {
        this.species = species;
    }

    /**
     * Returns the string representation of the CrewMembers object.
     * @return The string representation of the CrewMembers object
     */
    @NonNull
    @Override
    public String toString() {
        if (assignment.isEmpty()) {
            return "Crew Member: Name: " + name + ", Position: " + position + ", Rank: " + rank +
                    ", Species: " + species;
        }
        return "Crew Member: Name: " + name + ", Position: " + position + ", Rank: " + rank +
                ", Species: " + species + ", Assignment: " + assignment;
    }
}
