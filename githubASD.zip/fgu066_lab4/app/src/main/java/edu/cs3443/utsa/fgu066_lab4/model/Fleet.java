package edu.cs3443.utsa.fgu066_lab4.model;
import android.content.Context;
import android.content.res.AssetManager;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

/**
 * Fleet class represents a fleet of starships
 * It stores information such as name,shipList;
 * @author joseperdomo fgu066
 */
public class Fleet {
    private String name;
    private ArrayList<Starship> shipList = new ArrayList<>();
    private Context context;

    /** Fleet constructor for assignment
     * @param name
     * @param shipList
     */
    public Fleet(String name,ArrayList<Starship> shipList){
        this.name=name;
        this.shipList=shipList;
    }

    /**
     * getter for context
     * @return context
     */
    public Context getContext() {
        return context;
    }

    /**
     * getter for name of fleet
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * getter for shipList of fleet
     * @return shipList
     */
    public ArrayList<Starship> getShipList() {
        return shipList;
    }

    /**
     * setter for context
     * @param context
     */
    public void setContext(Context context) {
        this.context = context;
    }

    /**
     * setter for name of fleet
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * setter for shipList of fleet
     * @param shipList
     */
    public void setShipList(ArrayList<Starship> shipList) {
        this.shipList = shipList;
    }

    /**
     * getter for size of shipList
     * @return size of shiplist
     */
    public int getSizeOfFleet(){
        return shipList.size();
    }

    /**
     * addStarship is a method to add a ship to shipList
     * @param newShip
     */
    public void addStarship(Starship newShip){
        shipList.add(newShip);
    }


    /**
     * loadStarships is a method used to load the Shiplist of each fleet
     * @param fileName
     * @throws IOException
     */
    public void loadStarships(String fileName)throws IOException {
            AssetManager assetManager = context.getAssets();
            InputStream input = assetManager.open(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] dataSplits = line.split(",");
                String nameS = dataSplits[0];
                String registryS = dataSplits[1];
                String ClassS = dataSplits[2];
                ArrayList<CrewMembers> cList = new ArrayList<>();
                Starship ship = new Starship(nameS, registryS, ClassS, cList);
                shipList.add(ship);
            }
            reader.close();

    }


    /**
     * Returns the string representation of the CrewMembers object.
     * @return Returns the string representation of the CrewMembers object.
     */
    @Override
    public String toString() {
        String print = "";
        for (int x=0;x<shipList.size();x++) {
            print +="Ship Name : "+ getName() +", Registry: "+ shipList.get(x).getRegistry() +", Class: "+shipList.get(x).getShipClass() +"\n"+shipList.get(x) + "\n";
        }
        return print;
    }


}
