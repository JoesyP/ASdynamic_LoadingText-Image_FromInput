package edu.cs3443.utsa.fgu066_lab4.model;
import android.content.Context;
import android.content.res.AssetManager;

import androidx.annotation.NonNull;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

/**
 * Starship class is a class to represnt each starship
 * this includes ship name,registry,shipClass, and crewList
 * @author joseperdomo fgu066
 */
public class Starship {
    private Context context;

    private String name;
    private String registry;
    private String shipClass;

    private ArrayList<CrewMembers> crewList = new ArrayList<>();

    /**
     * Starship constructor for assignment
     * @param name
     * @param registry
     * @param shipClass
     * @param crewList
     */
    public Starship(String name,String registry,String shipClass,ArrayList<CrewMembers> crewList){
        this.name=name;
        this.registry=registry;
        this.shipClass=shipClass;
        this.crewList=crewList;

    }

    /**
     * Fleet constructor for assignment
     */
    public Starship() {
    }

    /**
     * getter for context
     * @return context
     */
    public Context getContext() {
        return context;
    }

    /**
     * getter for name of ship
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * getter for Registry of ship
     * @return Registry
     */
    public String getRegistry() {
        return registry;
    }

    /**
     * method to return crew member name and position
     * @param i
     * @return crewmember name and position
     */
    public String getMember(int i) {
        String print;
        print=crewList.get(i).getPosition()+"\n"+crewList.get(i).getName();
        return print;
    }

    /**
     * method to return crew member name only
     * @param i
     * @return Crewmember name
     */
    public String getMemberName(int i) {
        String print;
        print=crewList.get(i).getName();
        return print;
    }

    /**
     * getter for the ship class of starships
     * @return shipclass
     */
    public String getShipClass() {
        return shipClass;
    }

    /**
     * getter for crewList of starship
     * @return crewList
     */
    public ArrayList<CrewMembers> getCrewList() {
        return crewList;
    }

    /**
     * setter for context
     * @param context
     */
    public void setContext(Context context) {
        this.context = context;
    }

    /**
     * setter for name of starship
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * setter for registry of starship
     * @param registry
     */
    public void setRegistry(String registry) {
        this.registry = registry;
    }

    /**
     * setter for crewlist of starship
     * @param crewList
     */
    public void setCrewList(ArrayList<CrewMembers> crewList) {
        this.crewList = crewList;
    }

    /**
     * setter for shipclass of starship
     * @param shipClass
     */
    public void setShipClass(String shipClass) {
        this.shipClass = shipClass;
    }

    /**
     * method to add new member to the crewlist of starship
     * @param newMember
     */
    public void addCrewMember(CrewMembers newMember){
        crewList.add(newMember);
    }

    /**
     * method to return the number of people in crewlist
     * @return number of people in crewlist
     */
    public int getNumberOfPersonnel(){
        return crewList.size();
    }

    /**
     * method to load the members into there crewList depending on their registry
     * @param RegistryT
     * @return crewList
     * @throws IOException
     */
    public ArrayList<CrewMembers> loadCrewMembers(String RegistryT)throws IOException {
        AssetManager assetManager = context.getAssets();
        InputStream input = assetManager.open("personnel.csv");
        BufferedReader reader = new BufferedReader(new InputStreamReader(input));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] dataSplits = line.split(",");
            String nameT = dataSplits[0];
            String positionT = dataSplits[1];
            String rankT = dataSplits[2];
            String speciesT = dataSplits[4];
            String FileRegistry = dataSplits[3];
            if(RegistryT.equalsIgnoreCase(FileRegistry)) {
                CrewMembers crew = new CrewMembers(nameT, positionT, rankT, speciesT);
                crewList.add(crew);
            }
        }
        reader.close();
        return crewList;
    }

    /**
     * Returns the string representation of the Starship object.
     * @return Returns the string representation of the Starship object.
     */
    @NonNull
        @Override
        public String toString(){
            String print="";
            for(int i=0;i<crewList.size();i++){
                print+=crewList.get(i)+"\n";
            }
            return print;
        }

}
